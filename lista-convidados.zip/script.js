// ============================================================
//  ⚙️  CONFIGURAÇÕES — altere aqui
// ============================================================
const USUARIO     = 'admin';
const SENHA       = 'festa2025';
const STORAGE_KEY = 'convidados_v1';

// ============================================================
//  Dados — localStorage
// ============================================================
function loadGuests() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
  catch (e) { return []; }
}

function saveGuests(guests) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(guests));
}

// ============================================================
//  Telas
// ============================================================
function show(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ============================================================
//  Login / Logout
// ============================================================
function doLogin() {
  const u   = document.getElementById('loginUser').value.trim();
  const p   = document.getElementById('loginPass').value;
  const err = document.getElementById('loginErr');

  if (u === USUARIO && p === SENHA) {
    err.textContent = '';
    show('mainScreen');
    render();
  } else {
    err.textContent = 'Usuário ou senha incorretos.';
  }
}

function doLogout() {
  document.getElementById('loginUser').value = '';
  document.getElementById('loginPass').value = '';
  show('loginScreen');
}

// Enter no campo usuário → foca senha
document.getElementById('loginUser')
  .addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('loginPass').focus(); });

// Enter na senha → faz login
document.getElementById('loginPass')
  .addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

// ============================================================
//  Adicionar / Remover convidado
// ============================================================
function addGuest() {
  const name = document.getElementById('newName').value.trim();
  if (!name) return;

  const guests = loadGuests();
  guests.push({ id: Date.now(), name });
  saveGuests(guests);

  document.getElementById('newName').value = '';
  render();
}

// Enter no campo de nome → adiciona
document.getElementById('newName')
  .addEventListener('keydown', e => { if (e.key === 'Enter') addGuest(); });

function delGuest(id) {
  saveGuests(loadGuests().filter(g => g.id !== id));
  render();
}

// ============================================================
//  Renderizar lista
// ============================================================
function render() {
  const guests   = loadGuests();
  const q        = (document.getElementById('search')?.value || '').toLowerCase();
  const filtered = guests.filter(g => g.name.toLowerCase().includes(q));

  const countEl = document.getElementById('count');
  if (countEl) {
    countEl.innerHTML =
      `<span>${filtered.length}</span> convidado${filtered.length !== 1 ? 's' : ''}`;
  }

  const list = document.getElementById('guestList');
  if (!list) return;

  if (!filtered.length) {
    list.innerHTML = '<div class="empty">Nenhum convidado ainda.</div>';
    return;
  }

  list.innerHTML = filtered.map(g => `
    <div class="guest-row">
      <span class="guest-name">${g.name}</span>
      <button class="btn-del" onclick="delGuest(${g.id})" title="Remover">✕</button>
    </div>
  `).join('');
}

// ============================================================
//  Confetes — gerados dinamicamente
// ============================================================
(function gerarConfetes() {
  const cores = ['#ff4fa3','#ffcc00','#a855f7','#3b82f6','#ff6b35','#10b981','#f43f5e','#f59e0b'];
  const bg    = document.querySelector('.bg-festa');
  if (!bg) return;

  for (let i = 0; i < 40; i++) {
    const el = document.createElement('div');
    el.className = 'confetti-piece';
    el.style.cssText = `
      left: ${Math.random() * 100}%;
      top: -10px;
      background: ${cores[Math.floor(Math.random() * cores.length)]};
      width: ${4 + Math.random() * 8}px;
      height: ${4 + Math.random() * 8}px;
      border-radius: ${Math.random() > .5 ? '50%' : '2px'};
      animation-duration: ${8 + Math.random() * 14}s;
      animation-delay: ${Math.random() * 12}s;
    `;
    bg.appendChild(el);
  }
})();
