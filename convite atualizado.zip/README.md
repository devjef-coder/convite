# 🎉 Convite de Aniversário — Jefferson & Tamyres

Site de convite interativo para o aniversário de Jefferson e Tamyres, com tema de pagode.

## 📁 Estrutura

```
├── index.html   → Estrutura da página
├── style.css    → Estilos e animações
├── script.js    → Lógica e interatividade
└── README.md    → Este arquivo
```

## 🚀 Como usar

1. Faça o clone ou download do repositório
2. Abra o `index.html` no navegador — ou hospede no GitHub Pages

## 🌐 Hospedar no GitHub Pages

1. Faça upload dos arquivos no repositório
2. Vá em **Settings → Pages**
3. Em **Source**, selecione `main` e pasta `/ (root)`
4. Clique em **Save** — em minutos seu link estará ativo!

## ✨ Funcionalidades

- 🎭 Fundo animado de show de pagode (canvas)
- ⏳ Contagem regressiva até a festa
- 🎵 Instrumentos com sons interativos
- 🎊 Confetes ao confirmar presença
- 🎁 Sugestões de presentes por pessoa
- ✅ Confirmação de presença com links para o evento
- 📱 Responsivo para celular

## 👨‍💻 Desenvolvido por

Jefferson & Ryan
